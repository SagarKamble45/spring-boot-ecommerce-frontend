import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { MdShoppingBag } from "react-icons/md";

  import toast from "react-hot-toast";

// import ProductCard from "./ProductCard";
import FinalPrice from "../checkout_AI/FinalPrice";
import ProductItems from "../checkout_AI/ProductItems";
import { decreaseCartQuantity, increaseCartQuantity } from "../../store/action";

function OrderOverview() {
  const { cart } = useSelector((state) => state.carts);

  console.log(cart);

  return (
    <div>
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="h-11 w-11 rounded-xl bg-blue-100 flex items-center justify-center">
          <MdShoppingBag size={22} className="text-blue-600" />
        </div>

        <div>
          <h2 className="text-2xl font-bold text-slate-900">Order Summary</h2>

          <p className="text-sm text-gray-500">
            {cart?.length || 0} item(s) in your order
          </p>
        </div>
      </div>

      {/* Products */}
      <div className="space-y-4">
        {cart?.map((item, index) => (
          <ProductItems
            key={item?._id || index}
            {...item}
          />
        ))}
      </div>

      {/* Divider */}
      {/* <div className="my-6 border-t border-gray-100" /> */}

      {/* Pricing */}
      <FinalPrice newCart={cart} />
    </div>
  );
}

export default OrderOverview;
