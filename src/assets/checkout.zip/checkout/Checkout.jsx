import React from "react";
import { MdArrowBack, MdCreditCard } from "react-icons/md";
import { Link } from "react-router-dom";
import OrderOverview from "./OrderOverview";
import Address from "./Address";
import Payment from "./Payment";
import PlaceOrder from "./PlaceOrder";

function Checkout() {
  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-8 py-10">
      {/* Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-blue-100 mb-4">
          <MdCreditCard className="text-blue-600" size={32} />
        </div>

        <h1 className="text-4xl font-bold text-slate-900">
          Checkout
        </h1>

        <p className="text-gray-500 mt-2">
          Complete your order with secure payment
        </p>
      </div>

      {/* Main Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Order Summary */}
        <div className="lg:col-span-4">
          <div className="sticky top-24">
            <OrderOverview />
          </div>
        </div>

        {/* Checkout Sections */}
        <div className="lg:col-span-8">
          <div className="space-y-6">
            {/* Address */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <Address />
            </div>

            {/* Payment */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <Payment />
            </div>

            {/* Place Order */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <PlaceOrder />
            </div>
          </div>

          {/* Back To Cart */}
          <Link
            to="/cart"
            className="inline-flex items-center gap-2 mt-6 text-blue-600 hover:text-blue-700 font-medium"
          >
            <MdArrowBack />
            Back to Cart
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Checkout;