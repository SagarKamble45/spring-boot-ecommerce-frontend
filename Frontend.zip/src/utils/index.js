import { FaBoxOpen, FaHome, FaShoppingCart, FaStore, FaThList, FaUser } from "react-icons/fa";

export const bannerLists = [
  {
    id: 1,
    image: "https://picsum.photos/id/1060/1200/800",
    title: "Home Comfort",
    subtitle: "Living Room",
    description: "Upgrade your space with cozy and stylish sofas",
  },
  {
    id: 2,
    image: "https://picsum.photos/id/180/1200/800",
    title: "Entertainment Hub",
    subtitle: "Smart TV",
    description: "Experience the latest in home entertainment",
  },
  {
    id: 3,
    image: "https://picsum.photos/id/823/1200/800",
    title: "Playful Picks",
    subtitle: "Kids' Clothing",
    description: "Bright and fun styles for kids, up to 20% off",
  },
];


export const adminNavigation = [
  { name: "Dashboard", href: "/admin", icon: FaHome },
  { name: "Orders", href: "/admin/orders", icon: FaShoppingCart },
  { name: "Products", href: "/admin/products", icon: FaBoxOpen },
  { name: "Categories", href: "/admin/categories", icon: FaThList },
  { name: "Sellers", href: "/admin/sellers", icon: FaStore },
  { name: "Customers", href: "/admin/customers", icon: FaUser },
];
