import React, { useEffect } from "react";
import { MdCreditCard, MdOutlineAccountBalanceWallet, MdLocalShipping, MdPayments } from "react-icons/md";
import { useSelector, useDispatch } from "react-redux";
import { addPaymentMethod, addCardDetails, createUserCart } from "../../store/action/index.js";

// List of payment options.
// Only "card" (Stripe) is active for now. The rest are marked "pending"
// so they show up in the UI but cannot be selected yet.
const PAYMENT_OPTIONS = [
  {
    id: "card",
    name: "Pay with Card",
    subtitle: "Powered by Stripe",
    icon: MdCreditCard,
    pending: false,
  },
  {
    id: "razorpay",
    name: "Razorpay",
    subtitle: " Razorpay quick, easy, and secure way to pay online",
    icon: MdPayments,
    pending: false,
  },
  {
    id: "cashfree",
    name: "Cashfree",
    subtitle: "Coming soon",
    icon: MdPayments,
    pending: true,
  },
  {
    id: "payu",
    name: "PayU",
    subtitle: "Coming soon",
    icon: MdPayments,
    pending: true,
  },
  {
    id: "instamojo",
    name: "Instamojo",
    subtitle: "Coming soon",
    icon: MdPayments,
    pending: true,
  },
  {
    id: "phonepe",
    name: "PhonePe",
    subtitle: "Coming soon",
    icon: MdPayments,
    pending: true,
  },
  {
    id: "cod",
    name: "Cash on Delivery",
    subtitle: "Coming soon",
    icon: MdLocalShipping,
    pending: true,
  },
];

// Shape used whenever redux's cardDetails is still null (before the user
// has typed anything), so the inputs always have something to be
// "controlled" by.
const EMPTY_CARD = {
  nameOnCard: "",
  cardNumber: "",
  expiry: "",
  cvv: "",
};


// "4242424242424242" -> "4242 4242 4242 4242"
function formatCardNumber(value) {
  const digits = value.replace(/\D/g, "").slice(0, 16);
  return digits.replace(/(.{4})/g, "$1 ").trim();
}

// "1225" -> "12/25"
function formatExpiry(value) {
  const digits = value.replace(/\D/g, "").slice(0, 4);
  if (digits.length < 3) return digits;
  return `${digits.slice(0, 2)}/${digits.slice(2)}`;
}

function formatCvv(value) {
  return value.replace(/\D/g, "").slice(0, 4);
}

function Payment() {
  const dispatch = useDispatch();
  const { paymentMethod, cardDetails } = useSelector((state) => state.payment);
  const { cart, cartId } = useSelector((state) => state.carts);
  const { isLoading, errorMessage } = useSelector((state) => state.errors);

  // cardDetails starts out as `null` in the store (see initialState in
  // paymentMethodReducer), so fall back to an empty object until the user
  // types something.
  const currentCardDetails = cardDetails || EMPTY_CARD;

  const onSelectMethod = (method) => {
    dispatch(addPaymentMethod(method));
  };

  useEffect(() => {
    if (cart.length > 0 && !cartId && !errorMessage) {
      const sendCartItems = cart.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
      }));
      dispatch(createUserCart(sendCartItems));
    }
  }, [dispatch, cartId]);

  const handleCardChange = (e) => {
    const { name, value } = e.target;

    let nextValue = value;
    if (name === "cardNumber") nextValue = formatCardNumber(value);
    if (name === "expiry") nextValue = formatExpiry(value);
    if (name === "cvv") nextValue = formatCvv(value);

    // Redux is the single source of truth here (same pattern as
    // paymentMethod), so every keystroke dispatches the merged object
    // straight into the store.
    dispatch(addCardDetails({ ...currentCardDetails, [name]: nextValue }));
  };

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6">
      {/* Header */}
      <h2 className="text-xl font-bold text-slate-900">Payment</h2>
      <p className="text-gray-500 text-sm mt-1 mb-5">
        Select a payment option to continue
      </p>

      {/* List of payment options */}
      <div className="space-y-3">
        {PAYMENT_OPTIONS.map((option) => {
          const Icon = option.icon;
          const isSelected = paymentMethod === option.id;

          return (
            <button
              key={option.id}
              type="button"
              disabled={option.pending}
              onClick={() => onSelectMethod(option.id)}
              className={
                "w-full flex items-center gap-4 rounded-xl border p-4 text-left transition " +
                (option.pending
                  ? "border-gray-200 bg-gray-50 opacity-60 cursor-not-allowed"
                  : isSelected
                  ? "border-indigo-600 bg-indigo-50 cursor-pointer"
                  : "border-gray-200 hover:border-gray-300 cursor-pointer")
              }
            >
              {/* Icon */}
              <div
                className={
                  "w-10 h-10 rounded-full flex items-center justify-center text-xl " +
                  (isSelected ? "bg-indigo-600 text-white" : "bg-gray-100 text-gray-500")
                }
              >
                <Icon />
              </div>

              {/* Name + subtitle */}
              <div className="flex-1">
                <p className="font-semibold text-slate-900">{option.name}</p>
                <p className="text-xs text-gray-500">{option.subtitle}</p>
              </div>

              {/* Selected checkmark / Pending tag */}
              {option.pending ? (
                <span className="text-xs font-medium bg-gray-200 text-gray-600 px-2.5 py-1 rounded-full">
                  Pending
                </span>
              ) : (
                <div
                  className={
                    "w-5 h-5 rounded-full border-2 flex items-center justify-center " +
                    (isSelected ? "border-indigo-600" : "border-gray-300")
                  }
                >
                  {isSelected && <div className="w-2.5 h-2.5 rounded-full bg-indigo-600" />}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Card details form - only shown when "card" is selected */}
      {paymentMethod === "card" && (
        <div className="mt-6 pt-6 border-t border-gray-200 space-y-4">
          <p className="text-sm font-semibold text-slate-900">Card details</p>

          {/* Name on card */}
          <div>
            <label className="block text-sm text-gray-600 mb-1">Name on card</label>
            <input
              type="text"
              name="nameOnCard"
              value={currentCardDetails.nameOnCard}
              onChange={handleCardChange}
              placeholder="Full name"
              autoComplete="cc-name"
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          {/* Card number */}
          <div>
            <label className="block text-sm text-gray-600 mb-1">Card number</label>
            <input
              type="text"
              inputMode="numeric"
              name="cardNumber"
              value={currentCardDetails.cardNumber}
              onChange={handleCardChange}
              placeholder="1234 5678 9012 3456"
              autoComplete="cc-number"
              maxLength={19} // 16 digits + 3 spaces
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          {/* Expiry + CVV, side by side */}
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-sm text-gray-600 mb-1">Expiry (MM/YY)</label>
              <input
                type="text"
                inputMode="numeric"
                name="expiry"
                value={currentCardDetails.expiry}
                onChange={handleCardChange}
                placeholder="MM/YY"
                autoComplete="cc-exp"
                maxLength={5}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm text-gray-600 mb-1">CVV</label>
              <input
                type="password"
                inputMode="numeric"
                name="cvv"
                value={currentCardDetails.cvv}
                onChange={handleCardChange}
                placeholder="123"
                autoComplete="cc-csc"
                maxLength={4}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Payment;