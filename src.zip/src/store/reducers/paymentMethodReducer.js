const initialState = {
    paymentMethod:null,
    cardDetails:null,
    
    
};

export const paymentMethodReducer = (state = initialState, action) => {
    switch (action.type) {
        case "ADD_PAYMENT_METHOD":
            return {
                ...state,
                paymentMethod:action.payload,
            }
            
            case "ADD_CARD_DETAILS":
                return{
                    ...state,
                    cardDetails:action.payload,
                }
        default:
            return state;           
    }
    
    
};
